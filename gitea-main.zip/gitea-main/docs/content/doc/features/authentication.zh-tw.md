---
date: "2016-12-01T16:00:00+02:00"
title: "認證"
slug: "authentication"
weight: 10
toc: false
draft: false
menu:
  sidebar:
    parent: "features"
    name: "認證"
    weight: 10
    identifier: "authentication"
---

# 認證

## TBD
