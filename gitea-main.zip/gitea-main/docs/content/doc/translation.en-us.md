---
date: "2021-01-22T00:00:00+02:00"
title: "Translation"
slug: "translation"
weight: 35
toc: false
draft: false
menu:
  sidebar:
    name: "Translation"
    weight: 50
    identifier: "translation"
---
